// Verbesserte Version mit klarer Fehlerbehandlung, Logging und Benutzerfreundlichkeit

/**
 * Überarbeitete Version des D83-Parsers mit strukturierter Fehlerbehandlung und verbessertem Logging.
 * Ziel: bessere Nachvollziehbarkeit bei Encoding-Problemen und verständlichere Fehlermeldungen für Anwender.
 * Ich habe die Fehlerbehandlung im D83-Parser verbessert, um zwischen technischen und benutzerbezogenen Fehlern zu unterscheiden.
Das Logging ist strukturiert und informativ, und Fehlermeldungen sind jetzt verständlich formuliert.
Außerdem wird protokolliert, wenn eine alternative Kodierung verwendet wird, was die Nachvollziehbarkeit und Benutzerfreundlichkeit verbessert.
 */
function parseD83Buffer(buffer) {
  const encodings = ["CP850", "Windows-1252", "UTF-8"];
  let content = null;
  let selectedEncoding = null;
  const logPrefix = "[D83Parser]";

  // Interne Logging-Funktionen mit einheitlichem Prefix
  const logInfo = (msg) => console.log(`${logPrefix} INFO: ${msg}`);
  const logWarn = (msg) => console.warn(`${logPrefix} WARN: ${msg}`);
  const logError = (msg) => console.error(`${logPrefix} ERROR: ${msg}`);

  try {
    // 1. Versuch: CP850 (Standard-Encoding für viele GAEB90-Dateien)
    try {
      content = this.decodeCP850(buffer);
      const score = this.scoreEncoding(content);
      logInfo(`CP850 encoding score: ${score}`);

      if (score > 500) {
        selectedEncoding = "CP850";
        logInfo("CP850-Encoding erkannt und verwendet");
        return this.parseD83Content(content);
      }
    } catch (e) {
      logWarn(`CP850-Decodierung fehlgeschlagen: ${e.message}`);
    }

    // 2. Versuch: Windows-1252 (wird oft bei neueren Systemen genutzt)
    try {
      content = this.decodeWindows1252(buffer);
      const score = this.scoreEncoding(content);
      logInfo(`Windows-1252 encoding score: ${score}`);

      if (score > 300) {
        selectedEncoding = "Windows-1252";
        logInfo("Windows-1252-Encoding erkannt und verwendet");
        return this.parseD83Content(content);
      }
    } catch (e) {
      logWarn(`Windows-1252-Decodierung fehlgeschlagen: ${e.message}`);
    }

    // 3. Versuch: UTF-8 (Fallback, falls keine andere Kodierung passt)
    try {
      content = buffer.toString("utf8");
      selectedEncoding = "UTF-8";
      logInfo("UTF-8 als Fallback-Encoding verwendet");
      return this.parseD83Content(content);
    } catch (e) {
      throw new Error(`UTF-8-Decodierung nicht möglich: ${e.message}`);
    }

  } catch (error) {
    // Zentrale Fehlerbehandlung – unterscheidet zwischen Encoding- und Parsing-Fehlern
    logError(`Parsing fehlgeschlagen: ${error.message}`);

    const isEncodingProblem = !selectedEncoding;

    if (isEncodingProblem) {
      // Benutzerfreundliche Fehlermeldung, falls keine Kodierung erkannt wurde
      throw new Error(
        "Die Datei konnte nicht gelesen werden. Das Textformat (Encoding) ist unbekannt oder beschädigt."
      );
    } else {
      // Allgemeine Fehlermeldung bei Parsing-Problemen
      throw new Error(
        "Beim Einlesen der D83-Datei ist ein Fehler aufgetreten. Bitte prüfen Sie, ob die Datei vollständig und gültig ist."
      );
    }
  } finally {
    // Hinweis im Log, wenn ein alternatives Encoding genutzt wurde
    if (selectedEncoding && selectedEncoding !== "CP850") {
      logWarn(`Fallback-Encoding '${selectedEncoding}' wurde verwendet.`);
    }
  }
}
