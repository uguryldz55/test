import json
import re
from pathlib import Path

# Wörterbuch laden
CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "word_completions.json"
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    WORD_COMPLETIONS = json.load(f)

def recover_truncated_words(text: str) -> str:
    """
    Ersetzt abgeschnittene Baubegriffe (z. B. 'Elektroinstallatio') durch ihre vollständigen Formen.
    Nutzt Wortgrenzen, um Firmennamen usw. nicht zu verändern.
    """
    corrected = text
    for truncated, complete in WORD_COMPLETIONS.items():
        pattern = re.compile(rf"\b{re.escape(truncated)}\b", re.IGNORECASE)
        corrected = pattern.sub(complete, corrected)
    return corrected

if __name__ == "__main__":
    test_text = "Neubau eines Reihenhau mit Elektroinstallatio und Malerarbeite."
    print("Vorher:", test_text)
    print("Nachher:", recover_truncated_words(test_text))








"""
1. Branchenwissen
Deutsche Bau- und Ausschreibungsdaten enthalten viele standardisierte Begriffe („Elektroinstallation“, „Malerarbeiten“).
Wenn diese falsch erkannt oder abgeschnitten sind, können Leistungspositionen falsch zugeordnet oder kalkuliert werden.
Falsche Zuordnungen wirken sich direkt auf Ausschreibungen, Preise und Angebote aus.

2. Benutzerauswirkungen
Wenn ein Bauunternehmer eine GAEB- oder Excel-Datei mit „Elektroinstallatio“ hochlädt, erwartet er eine korrekte Interpretation.
Ich würde das System so bauen, dass Korrekturen automatisch erfolgen, aber zusätzlich eine Protokolldatei erstellt wird

So bleibt der Benutzer informiert und kann bei Bedarf manuell prüfen.

3. Leistung vs. Genauigkeit
Bei großen Dateien (z. B. 10 000 Zeilen) ist Performance entscheidend. In Python kann man:
	•	das Wörterbuch einmal beim Start laden,
	•	reguläre Ausdrücke vorkompilieren,
	•	bei Bedarf mit multiprocessing mehrere Abschnitte parallel verarbeiten.

z.b:in python from concurrent.futures import ThreadPoolExecutor


4. Wartung
Neue Baubegriffe entstehen laufend. Ich würde die JSON-Datei regelmäßig automatisch aus einer zentralen Datenquelle oder Branchen-API aktualisieren lassen. Die Anwendung liest sie beim Start ein – ohne Codeänderung oder Neustart nötig.

5. Randfälle
Begriff wie „Malerarbeite“ in „Malerarbeite GmbH“ soll nicht geändert werden. Darum verwende ich \b (Wortgrenzen) im Regex – so wird nur das reine Wort ersetzt, nicht zusammengesetzte Namen.

6. Internationalisierung
Für verschiedene Länder kann man getrennte Wörterlisten anlegen:
	word_completions.de.json
	word_completions.at.json
	word_completions.ch.json

und beim Start z. B. über eine Umgebungsvariable laden:	
	lang = os.getenv("REGION", "de")
	file = f"word_completions.{lang}.jso

Damit kann das System ohne Codeänderung regional angepasst werden.


"""