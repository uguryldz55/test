from src.text_corrector import recover_truncated_words

if __name__ == "__main__":
    text = input("Gib einen Beispieltext ein: ")
    corrected = recover_truncated_words(text)
    print("\n--- Ergebnis ---")
    print("Vorher:", text)
    print("Nachher:", corrected)
