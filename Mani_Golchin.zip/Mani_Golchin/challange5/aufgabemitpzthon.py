"""
Überarbeitete Python-Version von parseItem().
Optimierte Verarbeitung einzelner GAEB-/XML-Items mit Fokus auf Speicher,
Wartbarkeit und Fehlerrobustheit.
Der Code verarbeitet ein einzelnes GAEB-Item (z. B. eine Position aus einer XML- oder D83-Datei)
und wandelt es in ein sauberes Python-Dictionary um – also ein kompaktes, strukturiertes Datensatz-Objekt.
"""

import uuid


def generate_guid():
    """Erzeugt eine eindeutige ID (UUID4) – analog zu JS generateGUID()."""
    return str(uuid.uuid4())


def format_quantity(value):
    """Standardisiert Mengenangaben (z. B. '1,000' → '1.000')."""
    if not value:
        return ""
    return str(value).replace(",", ".").strip()


def format_price(value):
    """Formatiert Preisangaben in einheitlicher Schreibweise."""
    if not value:
        return ""
    return str(value).replace(",", ".").strip()


def parse_item(item: dict, category_number: str, item_index: int) -> dict:
    """
    Verarbeitet ein einzelnes GAEB-Item und erzeugt ein optimiertes Positionsobjekt.
    Nutzt defensive Programmierung, um fehlerhafte Daten sicher zu behandeln.
    """
    position = {}

    # Grundinformationen
    position["type"] = "Position"
    position["guid"] = item.get("ID", generate_guid())

    # OZ-Nummer (Positionsnummer, dreistellig mit führenden Nullen)
    position["oz"] = f"{category_number}.{item_index * 10:03}"

    # Kurz- und Langtexte (nur setzen, wenn vorhanden)
    if "ShortText" in item and item["ShortText"]:
        position["shortText"] = item["ShortText"][0].strip()
    if "LongText" in item and item["LongText"]:
        position["longText"] = item["LongText"][0].strip()

    # Menge (Qty) – vereinfacht und wiederverwendbar
    qty = item.get("Qty", [None])[0]
    if isinstance(qty, str):
        position["quantity"] = format_quantity(qty)
    elif isinstance(qty, dict):
        position["quantity"] = format_quantity(qty.get("_") or qty.get("$") or "")

    # Einheit (QU) – robust gegen verschiedene XML-Strukturen
    qu = item.get("QU", [None])[0]
    if isinstance(qu, str):
        position["unit"] = qu.strip()
    elif isinstance(qu, dict):
        position["unit"] = (qu.get("_") or "").strip()

    # Pauschalpositionen ("LumpSumItem")
    lump_sum = item.get("LumpSumItem", [None])[0]
    if lump_sum == "Yes":
        position["unit"] = position.get("unit", "psch")
        position["quantity"] = position.get("quantity", "1.000")

    # Preise (optional)
    if "UnitPrice" in item and item["UnitPrice"]:
        position["unitPrice"] = format_price(item["UnitPrice"][0])
    if "TotalPrice" in item and item["TotalPrice"]:
        position["totalPrice"] = format_price(item["TotalPrice"][0])

    # Mehrwertsteuer – Standardwert 0,00 wenn nicht angegeben
    position["mwst"] = item.get("Mwst", ["0,00"])[0]

    return position
