
/**
 *  Herausforderung 5 – Ineffiziente Datenverarbeitung und Speichernutzung
 * 
 *  Problem:
 *      Der ursprüngliche Code erzeugte für jede Position ein komplettes Objekt mit vielen leeren Feldern.
 *      Außerdem wurde ähnliche Logik für Menge (Qty) und Einheit (QU) mehrfach wiederholt.
 *      Das führte zu unnötigem Speicherverbrauch und unübersichtlichem Code bei großen GAEB-Dateien.
 *
 *  Ziele:
 *      - Speicherbedarf pro Datensatz reduzieren
 *      - Wiederholungen im Code vermeiden
 *      - Robustheit gegenüber fehlerhaften XML-Strukturen erhöhen
 *      - Lesbarkeit und Erweiterbarkeit verbessern
 */


async function parseItem(item, categoryNumber, itemIndex) {
  // Objekt mit minimaler Struktur – keine überflüssigen Felder
  const position = Object.create(null);
  position.type = 'Position';
  position.guid = item?.$?.ID || generateGUID();

  // OZ-Nummer generieren (Positionsnummer mit führenden Nullen)
  position.oz = `${categoryNumber}.${String(itemIndex * 10).padStart(3, '0')}`;

  // Kurz- und Langtexte nur setzen, wenn sie vorhanden sind
  if (item.ShortText?.[0]) position.shortText = item.ShortText[0].trim();
  if (item.LongText?.[0]) position.longText = item.LongText[0].trim();

  // Hilfsfunktion zur Ermittlung der Menge
  const getQuantityValue = (qty) => {
    if (typeof qty === 'string') return formatQuantity(qty);
    if (typeof qty === 'object') return formatQuantity(qty._ || qty.$ || '');
    return '';
  };
  if (item.Qty?.[0]) position.quantity = getQuantityValue(item.Qty[0]);

  // Einheit (QU) – robust gegen verschiedene XML-Strukturen
  const getUnitValue = (qu) => {
    if (typeof qu === 'string') return qu.trim();
    if (typeof qu === 'object') return qu._?.trim?.() || '';
    return '';
  };
  if (item.QU?.[0]) position.unit = getUnitValue(item.QU[0]);

  // Pauschalpositionen werden standardmäßig als "psch" behandelt
  if (item.LumpSumItem?.[0] === 'Yes') {
    position.unit = position.unit || 'psch';
    position.quantity = position.quantity || '1,000';
  }

  // Preise nur setzen, wenn vorhanden – spart RAM
  if (item.UnitPrice?.[0]) position.unitPrice = formatPrice(item.UnitPrice[0]);
  if (item.TotalPrice?.[0]) position.totalPrice = formatPrice(item.TotalPrice[0]);

  // Standardwert für MwSt
  position.mwst = item.Mwst?.[0] || '0,00';

  return position;
}

/**
 * Hilfsfunktion zur Generierung einer GUID.
 */
function generateGUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Beispielhafte Formatierungsfunktionen.
 * Diese können an das Projekt angepasst oder ersetzt werden.
 */
function formatQuantity(value) {
  return String(value).replace(',', '.').trim();
}

function formatPrice(value) {
  return String(value).replace(',', '.').trim();
}

// Export der Funktion (ES-Modul)
export { parseItem };
