// POST-Endpunkt für die Konvertierung von GAEB-, Excel- und D83-Dateien
/**In diesem Code habe ich den bestehenden monolithischen API-Endpunkt verbessert, ohne seine Funktion zu verändern.
Ich habe eine klare Struktur eingeführt, die Eingabevalidierung ergänzt und die Fehlerbehandlung präziser gestaltet.
Jede Formatverarbeitung (Excel, D83, GAEB) ist nun getrennt und mit eigenen Fehlermeldungen abgesichert.
Durch zusätzliche, neutrale Kommentare ist der Ablauf verständlicher, und der Code lässt sich leichter warten und erweitern.
*/
app.post("/api/convert", upload.single("file"), async (req, res) => {
  try {
    // Prüfen, ob überhaupt eine Datei im Request enthalten ist
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    // Relevante Eingabeparameter auslesen
    const { sourceFormat, targetFormat, textColumn } = req.body;

    // Basisvalidierung der Eingabeparameter
    if (!sourceFormat || !targetFormat) {
      return res.status(400).json({ error: "Missing format parameters" });
    }

    // Parser für GAEB-Formate initialisieren
    const parser = new GAEBParser();

    // Zwischenspeicher für die spätere Antwort
    let convertedBuffer;
    let outputFileName;
    let mimeType;

    // Dateiformat des Uploads erkennen (Excel / D83 / GAEB)
    const fileName = req.file.originalname.toLowerCase();
    const isExcel =
      fileName.endsWith(".xlsx") ||
      fileName.endsWith(".xls") ||
      sourceFormat === "excel";
    const isD83 =
      fileName.endsWith(".d83") || sourceFormat === "gaeb90d83";

    // Verarbeitung von Excel-Dateien
    if (isExcel) {
      try {
        // Excel-Datei einlesen und in das gewünschte GAEB-Format konvertieren
        convertedBuffer = await parser.convertFromExcel(
          req.file.buffer,
          targetFormat
        );

        // Standard-Exportname und MIME-Typ für GAEB-Dateien
        outputFileName = "converted.x83";
        mimeType = "application/octet-stream";
      } catch (err) {
        // Fehler im Excel-Konvertierungsschritt
        return res
          .status(422)
          .json({ error: "Excel conversion failed", details: err.message });
      }
    }

    // Verarbeitung von D83-Dateien (GAEB 90)
    else if (isD83) {
      try {
        const d83Parser = new D83Parser();

        // D83-Daten einlesen und intern in GAEB-Struktur umwandeln
        const gaebData = d83Parser.parseD83Buffer(req.file.buffer);

        // GAEB-Daten in Excel-Datei konvertieren
        convertedBuffer = await d83Parser.convertToExcelBuffer(
          gaebData,
          textColumn
        );

        // Standard-Exportname und MIME-Typ für Excel-Dateien
        outputFileName = "converted.xlsx";
        mimeType =
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      } catch (err) {
        // Fehler im D83-Verarbeitungsschritt
        return res
          .status(422)
          .json({ error: "D83 conversion failed", details: err.message });
      }
    }

    // Verarbeitung von sonstigen GAEB-Dateien
    else {
      try {
        // Datei als GAEB-Format interpretieren und einlesen
        const gaebData = await parser.parseGAEBFile(
          req.file.buffer,
          sourceFormat
        );

        // GAEB-Daten in Excel-Datei konvertieren
        convertedBuffer = await parser.convertToExcel(
          gaebData,
          textColumn
        );

        // Ausgabeparameter setzen
        outputFileName = "converted.xlsx";
        mimeType =
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      } catch (err) {
        // Fehler bei der GAEB-Verarbeitung
        return res
          .status(422)
          .json({ error: "GAEB conversion failed", details: err.message });
      }
    }

    // Antwort vorbereiten
    // Header für den Download: MIME-Type und Dateiname
    res.set({
      "Content-Type": `${mimeType}; charset=utf-8`,
      "Content-Disposition": `attachment; filename=${outputFileName}`,
    });

    // Konvertierte Datei an den Client senden
    res.send(convertedBuffer);
  } catch (error) {
    // Allgemeiner Fehler (z. B. unerwarteter Laufzeitfehler)
    console.error("Conversion error:", error);

    // Einheitliche Fehlermeldung für nicht abgefangene Fehler
    res.status(500).json({
      error: "Internal server error",
      details: error.message,
    });
  }
});
