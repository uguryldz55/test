"""
Herausforderung 3 – Monolithischer API-Endpunkt mit schlechter Fehlerbehandlung (Python-Version)

Überarbeitete Variante des Datei-Konvertierungsendpunkts.
Ziel: Trennung der Verantwortlichkeiten, robuste Fehlerbehandlung,
Formatvalidierung und saubere Antwortstruktur.
"""

from flask import Flask, request, jsonify, send_file
from werkzeug.utils import secure_filename
import io
import traceback

app = Flask(__name__)

class GAEBParser:
    def convert_from_excel(self, buffer, target_format):
        # Konvertiert Excel-Daten in ein GAEB-kompatibles Format
        return buffer

    def parse_gaeb_file(self, buffer, source_format):
        # Liest eine GAEB-Datei ein und extrahiert relevante Datenstrukturen
        return {"positions": [], "projectInfo": {}}

    def convert_to_excel(self, data, text_column):
        # Erstellt aus GAEB-Daten eine Excel-Datei
        return io.BytesIO(b"Excel data")

    def create_gaeb90(self, positions):
        # Erstellt eine GAEB90-Datei aus Positionsdaten
        return io.BytesIO(b"GAEB90 data")

    def create_gaebxml(self, positions, project_info, target_format):
        # Erstellt eine XML-Datei im GAEB-Format
        return io.BytesIO(b"<xml></xml>")


class D83Parser:
    def parse_d83_buffer(self, buffer):
        # Liest eine GAEB-D83-Datei (älteres Format) ein und liefert strukturierte Daten zurück
        return {"positions": [], "projectInfo": {}}

    def convert_to_excel_buffer(self, data, text_column):
        # Konvertiert D83-Daten direkt in eine Excel-Datei
        return io.BytesIO(b"Excel data from D83")


# Hilfsfunktionen zur Validierung, Format-Erkennung und HTTP-Antwort-Erstellung

def detect_source_format(filename, explicit_format=None):
    """Bestimmt das Quellformat anhand der Dateiendung oder eines übergebenen Formats."""
    name = filename.lower()
    if name.endswith((".xlsx", ".xls")) or explicit_format == "excel":
        return "excel"
    if name.endswith(".d83") or explicit_format == "gaeb90d83":
        return "gaeb90d83"
    if name.endswith((".x83", ".x84", ".xml")):
        return "gaeb"
    # Wird kein bekanntes Format erkannt, wird ein Fehler ausgelöst
    raise ValueError("Unbekanntes Quellformat")


def validate_file(file_storage):
    """Prüft, ob eine Datei vorhanden und der Name gültig ist."""
    if not file_storage:
        raise ValueError("Keine Datei hochgeladen.")
    filename = secure_filename(file_storage.filename)
    if not filename:
        raise ValueError("Ungültiger Dateiname.")
    return filename


def create_response(buffer, filename, mimetype):
    """Erstellt eine standardisierte HTTP-Antwort mit der konvertierten Datei."""
    return send_file(
        io.BytesIO(buffer.getvalue()),
        mimetype=mimetype,
        as_attachment=True,
        download_name=filename
    )


# Haupt-Endpunkt der API – /api/convert

@app.route("/api/convert", methods=["POST"])
def convert_file():
    try:
        # Eingabevalidierung: Prüfen, ob Datei und Formate korrekt angegeben wurden
        uploaded_file = request.files.get("file")
        filename = validate_file(uploaded_file)
        source_format = request.form.get("sourceFormat", "").strip()
        target_format = request.form.get("targetFormat", "").strip()
        text_column = request.form.get("textColumn", "").strip()

        parser = GAEBParser()
        buffer = io.BytesIO(uploaded_file.read())

        # Bestimmen, welches Quellformat vorliegt (Excel, D83, GAEB etc.)
        detected_format = detect_source_format(filename, source_format)
        print(f"Detected source format: {detected_format}")

        converted_buffer = None
        output_filename = None
        mime_type = None

        
        # Fall 1: Quelle ist eine Excel-Datei → wird in GAEB-Format umgewandelt
        
        if detected_format == "excel":
            converted_buffer = parser.convert_from_excel(buffer, target_format)
            output_filename = f"converted.{target_format}"
            mime_type = "application/octet-stream"

        
        # Fall 2: Quelle ist eine D83-Datei → Konvertierung zu Excel oder GAEB
        
        elif detected_format == "gaeb90d83":
            d83_parser = D83Parser()
            gaeb_data = d83_parser.parse_d83_buffer(buffer)

            if target_format in ("excel", "xlsx"):
                # Umwandlung in Excel-Datei
                converted_buffer = d83_parser.convert_to_excel_buffer(gaeb_data, text_column)
                output_filename = filename.replace(".d83", ".xlsx")
                mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            else:
                # Umwandlung in GAEB90-Format
                converted_buffer = parser.create_gaeb90(gaeb_data["positions"])
                output_filename = "converted.x83"
                mime_type = "application/octet-stream"

        
        # Fall 3: Quelle ist bereits eine GAEB-Datei → Konvertierung zu Excel oder XML
       
        elif detected_format == "gaeb":
            gaeb_data = parser.parse_gaeb_file(buffer, source_format)

            if target_format in ("excel", "xlsx"):
                converted_buffer = parser.convert_to_excel(gaeb_data, text_column)
                output_filename = filename.replace(".x83", ".xlsx")
                mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            elif "xml" in target_format:
                converted_buffer = parser.create_gaebxml(
                    gaeb_data["positions"], gaeb_data["projectInfo"], target_format
                )
                output_filename = "converted.xml"
                mime_type = "application/xml"
            else:
                # Standardmäßig: GAEB90-Konvertierung
                converted_buffer = parser.create_gaeb90(gaeb_data["positions"])
                output_filename = "converted.x83"
                mime_type = "application/octet-stream"

        else:
            # Wenn kein Format erkannt wurde
            raise ValueError("Unbekanntes Eingabeformat.")

        # Datei als Download-Antwort zurückgeben
        return create_response(converted_buffer, output_filename, mime_type)

    
    # Fehlerbehandlung: Benutzerfehler (400) oder Serverfehler (500)
    
    except ValueError as ve:
        # Fehler durch ungültige Eingabe oder fehlende Datei
        return jsonify({"error": str(ve)}), 400

    except Exception as e:
        # Allgemeiner Fehlerfall – z. B. unerwartete Laufzeitfehler
        traceback.print_exc()
        return jsonify({
            "error": "Konvertierung fehlgeschlagen.",
            "details": str(e)
        }), 500



# Entwicklungsmodus: Startet den Flask-Webserver für lokale Tests

if __name__ == "__main__":
    app.run(debug=True)
