"""
Herausforderung 7 – Konfiguration und Geschäftsregeln (Python-Version)

Ziel:
Geschäftslogik und Konfigurationswerte werden aus dem Code ausgelagert,
um Wartbarkeit und Flexibilität zu erhöhen.

 diese fest eingebauten Werte aus dem Code herauszulösen  und stattdessen aus einer Konfigurationsdatei (config.json) zu laden.
    So kann man:
        Regeln und Parameter ohne Codeänderung anpassen,
        denselben Code in verschiedenen Märkten (z. B. Deutschland, Schweiz) verwenden,
        die Geschäftslogik klar von der Implementierung trennen.
"""

import json
from pathlib import Path


class ConfigManager:
    """Lädt und verwaltet Konfigurationseinstellungen aus externer Datei."""

    def __init__(self, config_path="config.json"):
        config_file = Path(config_path)
        if not config_file.exists():
            raise FileNotFoundError(f"Konfigurationsdatei {config_path} fehlt.")
        with open(config_file, "r", encoding="utf-8") as f:
            self.config = json.load(f)

    def get(self, section, key, default=None):
        """Gibt einen Konfigurationswert zurück."""
        return self.config.get(section, {}).get(key, default)


class D83Parser:
    """Parser mit externer Konfiguration und flexiblen Geschäftsregeln."""

    def __init__(self, config: ConfigManager):
        self.positions = []
        self.groups = []
        self.project_info = {
            "projectName": "",
            "description": "",
            "currency": config.get("project", "currency", "EUR")
        }

        # Geschäftsregeln und Schwellenwerte
        self.encoding_rules = config.get("encoding_rules", {})
        self.standard_flags = config.get("gaeb_standards", {})

    def score_encoding(self, content_scores):
        """
        Wählt das passende Encoding basierend auf konfigurierbaren Schwellenwerten.
        content_scores = {"CP850": 510, "Windows-1252": 300, "UTF-8": 150}
        """
        for enc, score in content_scores.items():
            threshold = self.encoding_rules.get(enc, 0)
            if score >= threshold:
                return enc
        return "UTF-8"  # Fallback

    def summarize_project_info(self):
        """Beispielmethode zur Ausgabe von Projektinformationen."""
        return f"{self.project_info['projectName']} – Währung: {self.project_info['currency']}"


# Testblock: Wird nur ausgeführt, wenn die Datei direkt gestartet wird.
# Lädt die Konfiguration aus 'config.json', erstellt einen D83Parser mit diesen Einstellungen
# und führt einen Testlauf durch, um das erkannte Encoding und die Projektinformationen auszugeben.
# So kann das Verhalten des Parsers unabhängig vom restlichen Programm überprüft werden.

if __name__ == "__main__":
    config = ConfigManager("config.json")
    parser = D83Parser(config)

    test_scores = {"CP850": 520, "Windows-1252": 280, "UTF-8": 100}
    print("Erkanntes Encoding:", parser.score_encoding(test_scores))
    print(parser.summarize_project_info())

