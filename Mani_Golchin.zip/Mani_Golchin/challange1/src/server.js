const express = require("express");
const multer = require("multer");
const config = require("config");

const app = express();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, config.get("upload.path"));
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: config.get("upload.maxFileSizeMB") * 1024 * 1024 }
});

app.post("/upload", upload.single("file"), (req, res) => {
  res.json({ message: "Upload erfolgreich", file: req.file });
});

app.listen(8080, () => console.log("Server läuft auf Port 8080"));
