const config = require("config");

function addPositionFormulas(worksheet, row) {
  const col = config.get("excelColumns");

  const menge = String.fromCharCode(64 + col.menge);
  const preis = String.fromCharCode(64 + col.einheitspreis);
  const gesamt = String.fromCharCode(64 + col.gesamtpreis);

  worksheet.getCell(row, col.gesamtpreis).formula =
    `=IFERROR(IF(OR(ISBLANK(${menge}${row.number}),ISBLANK(${preis}${row.number})),"",${menge}${row.number}*${preis}${row.number}),"")`;
}

module.exports = { addPositionFormulas };
