"""
Herausforderung 6 – Frontend-Fehlerbehandlung und Benutzerfeedback (Python-Version)

Ziel:
Die ursprüngliche JavaScript-Funktion wurde überarbeitet und in Python übertragen.
Diese Version simuliert denselben Ablauf: Datei wird „hochgeladen“, verarbeitet
und der Benutzer erhält eine klare Rückmeldung zu Fortschritt, Fehlern oder Erfolg.

Das Programm:
    zeigt Upload- und Konvertierungsfortschritt,
    erkennt verschiedene Fehler (falsche Datei, Netzwerkfehler, Serverfehler),
    versucht den Vorgang bei Fehlern automatisch nochmal,
    und gibt klare, verständliche Rückmeldungen für den Benutzer.
"""


import time
import random


class ConversionError(Exception):
    """Eigene Ausnahme für Fehler während Upload oder Konvertierung."""
    pass


def simulate_upload(file_path: str):
    """Simuliert einen Datei-Upload mit Fortschrittsanzeige und möglichem Fehler."""
    print(f"\nLade '{file_path}' hoch ...")
    for i in range(0, 101, 20):
        time.sleep(0.3)
        print(f"  Fortschritt: {i}%")
    # Zufälliger Fehler zur Simulation eines Netzwerkproblems
    if random.choice([False, False, True]):
        raise ConversionError("Verbindungsfehler beim Upload.")


def simulate_conversion():
    """Simuliert den eigentlichen Konvertierungsvorgang."""
    print("\nKonvertierung gestartet ...")
    for i in range(0, 101, 25):
        time.sleep(0.4)
        print(f"  Fortschritt: {i}%")
    # Zufälliger Fehler zur Simulation eines Serverfehlers
    if random.choice([False, True, False]):
        raise ConversionError("Serverfehler bei der Konvertierung.")


def convert_file(file_path: str):
    """
   Das Programm:
        zeigt Upload- und Konvertierungsfortschritt,
        erkennt verschiedene Fehler (falsche Datei, Netzwerkfehler, Serverfehler),
        versucht den Vorgang bei Fehlern automatisch nochmal,
        und gibt klare, verständliche Rückmeldungen für den Benutzer.
    """
    max_retries = 2
    attempt = 0

    while attempt <= max_retries:
        try:
            if not file_path:
                raise ValueError("Keine Datei angegeben.")
            if not file_path.lower().endswith((".d83", ".x83", ".xlsx", ".xls")):
                raise ValueError("Ungültiger Dateityp. Nur D83/X83 oder Excel erlaubt.")

            simulate_upload(file_path)
            simulate_conversion()

            print("\nKonvertierung erfolgreich abgeschlossen.")
            print(f"Die Datei '{file_path}' wurde erfolgreich konvertiert.")
            break

        except ValueError as ve:
            print(f"\nEingabefehler: {ve}")
            break

        except ConversionError as ce:
            attempt += 1
            print(f"\nFehler: {ce}")
            if attempt <= max_retries:
                print(f"Neuer Versuch ({attempt}/{max_retries}) ...")
                time.sleep(1)
            else:
                print("Maximale Versuche erreicht. Vorgang abgebrochen.")
                break

        except KeyboardInterrupt:
            print("\nVorgang vom Benutzer abgebrochen.")
            break

        except Exception as e:
            print(f"\nUnerwarteter Fehler: {e}")
            break

        finally:
            print("\nStatus: Upload abgeschlossen, Fortschrittsanzeige beendet.")
            time.sleep(0.5)


if __name__ == "__main__":
    print("=== Datei-Konvertierung (Python-Simulation) ===")
    user_file = input("Dateipfad eingeben: ").strip()
    convert_file(user_file)
