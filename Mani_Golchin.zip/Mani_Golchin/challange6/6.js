/**
 * Herausforderung 6 
 * Verbesserte Version der Upload-/Konvertierungslogik mit besserer Nutzerführung,
 * Fehlerdifferenzierung, Fortschrittsanzeige und Wiederholungsmöglichkeit.
 * 
 * In dieser verbesserten Version wird der Benutzer aktiv geführt:
    Der Code prüft den Dateityp, zeigt eine Fortschrittsanzeige während des Uploads und gibt unterschiedliche Fehlermeldungen je nach Ursache aus (z. B. Serverfehler, Timeout, Offline).
    Durch den AbortController werden lange Wartezeiten verhindert, und über Fokussteuerung (errorMessage.focus()) ist der Code barrierefrei.
    Die Hilfsfunktionen showError, showMessage und setProgress trennen Logik und UI klar voneinander, wodurch der Code übersichtlich und leicht wartbar bleibt.
 */

convertBtn.addEventListener("click", async () => {
  // Prüfen, ob eine Datei ausgewählt wurde
  if (!selectedFile) {
    showError("Bitte wählen Sie zuerst eine Datei aus.");
    return;
  }

  // Clientseitige Dateitypprüfung
  const allowedTypes = [".d83", ".x83", ".xlsx", ".xls"];
  const fileName = selectedFile.name.toLowerCase();
  if (!allowedTypes.some((ext) => fileName.endsWith(ext))) {
    showError("Ungültiger Dateityp. Erlaubt sind D83/X83 oder Excel-Dateien.");
    return;
  }

  // Fortschrittsanzeige aktivieren
  setProgress("uploading");
  convertBtn.disabled = true;

  try {
    // Formulardaten zusammenstellen
    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("sourceFormat", sourceFormat.value);
    formData.append("targetFormat", targetFormat.value);
    formData.append("textColumn", textColumn.value);

    // Timeout-Mechanismus für langsame Server oder Netzprobleme
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    // Anfrage an Backend senden
    const response = await fetch("/api/convert", {
      method: "POST",
      body: formData,
      signal: controller.signal,
    });

    clearTimeout(timeout);

    // HTTP-Fehler abfangen
    if (!response.ok) {
      const msg =
        response.status === 500
          ? "Serverfehler bei der Konvertierung."
          : `Fehler beim Hochladen (Status ${response.status}).`;
      throw new Error(msg);
    }

    // Antwort als Datei verarbeiten
    const blob = await response.blob();
    const fileUrl = URL.createObjectURL(blob);

    // Erfolgsanzeige
    setProgress("success");

    // Automatischer Download
    const link = document.createElement("a");
    link.href = fileUrl;
    link.download = `converted_${selectedFile.name}`;
    document.body.appendChild(link);
    link.click();
    link.remove();

    showMessage("Datei erfolgreich konvertiert und heruntergeladen.");

  } catch (err) {
    // Fehlerbehandlung nach Art des Fehlers
    if (err.name === "AbortError") {
      showError("Zeitüberschreitung. Bitte versuchen Sie es erneut.");
    } else if (!navigator.onLine) {
      showError("Keine Internetverbindung. Bitte prüfen Sie Ihr Netzwerk.");
    } else {
      showError(err.message || "Unbekannter Fehler beim Konvertieren.");
    }
  } finally {
    // Tastenstatus und Fortschrittsanzeige zurücksetzen
    convertBtn.disabled = false;
    setProgress("hidden");
  }
});

/**
 * Fortschrittsanzeige (Upload läuft / Erfolg / Versteckt)
 */
function setProgress(state) {
  switch (state) {
    case "uploading":
      progressBar.style.display = "block";
      statusText.textContent = "Upload läuft...";
      progressBar.setAttribute("aria-busy", "true"); // Barrierefreiheit
      break;
    case "success":
      progressBar.style.display = "none";
      statusText.textContent = "Upload erfolgreich.";
      break;
    default:
      progressBar.style.display = "none";
      statusText.textContent = "";
  }
}

/**
 * Fehleranzeige mit Fokussteuerung für Screenreader
 */
function showError(message) {
  errorMessage.textContent = message;
  error.style.display = "block";
  progressBar.style.display = "none";
  errorMessage.focus(); // Barrierefreiheit
}

/**
 * Allgemeine Statusmeldung (z. B. Erfolg)
 */
function showMessage(message) {
  error.style.display = "none";
  statusText.textContent = message;
}
